// import { CleanPlugin } from "webpack";

// tutaj będzie tworzony kod
const inputMl = document.querySelector('.input-water-ml');
const inputGlass = document.querySelector('.input-water-number');

const plusBtn = document.querySelector('.btn-plus');
const minusBtn = document.querySelector('.btn-minus');

let glassOfWater = 0;
let amoutOfWater = 0;

const addGlass = function() {
    glassOfWater += 1;
    amoutOfWater += 250;
    inputMl.value = amoutOfWater + 'ml';
    inputGlass.value = glassOfWater;
}

const decWater = function() {
    if(inputMl.value === "0" || inputGlass.value === "0") return;
    glassOfWater -= 1;
    amoutOfWater -= 250;
    inputMl.value = amoutOfWater + "ml";
    inputGlass.value = glassOfWater;
}

plusBtn.addEventListener('click', addGlass);

minusBtn.addEventListener('click', decWater);