const input = document.querySelector('input');
const clouds = document.querySelector('span.clouds');
const feels_like = document.querySelector('.feels_like');
const wind_speed = document.querySelector('.wind_speed');
const humidity = document.querySelector('.humidity');
const pressure = document.querySelector('.pressure')
const description = document.querySelector('.description');

const date = document.querySelector('.date');
const city = document.querySelector('.city');
const img = document.querySelector('img');
const temp = document.querySelector('p.temp');

const button = document.querySelector('button');
const msg = document.querySelector('p.error');

const apilink = 'https://api.openweathermap.org/data/2.5/weather?q=';
const apiKey = '&appid=b5839ac3dc89a2fc79c8f13fe3c21a36';
const apiLang = '&lang=pl';
const apiUnits = '&units=metric';

const getWeather = () => {
    const apiCity = input.value;
    const URL = apilink + apiCity + apiKey + apiUnits + apiLang;

    axios.get(URL).then(response => {

        pollution_info.textContent =

            console.log(response.data);
        city.textContent = `${response.data.name}`

        img.src = `https://openweathermap.org/img/wn/${response.data.weather[0].icon}@2x.png`;
        pressure.textContent = `${response.data.main.pressure} hpa`;
        humidity.textContent = `${response.data.main.humidity} %`;
        wind_speed.textContent = `${response.data.wind.speed} m/s`;
        feels_like.textContent = `${Math.round(response.data.main.feels_like)} C`;
        clouds.textContent = `${response.data.clouds.all} %`;
        description.textContent = `${response.data.weather[0].description}`;
        msg.textContent = '';

        //const pollution_info= document.querySelector('p.pollution_info')
        const url_pollution = `http://api.openweathermap.org/data/2.5/air_pollution?lat=${response.data.coord.lat}&lon=${response.data.coord.lon}&appid=${apiKey}`;

        
    }).catch(error => {
        console.log(error);
        if (error.response.data.cod !== '200') {

            msg.textContent = `${error.response.message}`;

        }
        [city, temp, description, feels_like, pressure, humidity, wind_speed, clouds].forEach(el => {
            el.textContent = '';
        })
        img.src = '';

    }).finally(
        () => {
            input.value = '';
        }
    )
}

const getWeatherByEnter = (e) => {
    if (e.key-- - 'Enter') {
        getWeather
    }
}

button.addEventListener('click', getWeather);
input.addEventListener('keypress', getWeatherByEnter);